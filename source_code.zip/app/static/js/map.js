/* app/static/js/map.js */

let map;
let schoolMarkers = [];
let univMarkers = [];
let markerCluster;
let infoWindow;
let ICONS = {}; // 전역 선언

function initMap() {
    // 1. 데이터 확인
    const dataCount = (typeof SCHOOLS_DATA !== 'undefined') ? SCHOOLS_DATA.length : 0;
    console.log("🏫 Data Loaded:", dataCount);

    // 2. ICONS 초기화 (구글 객체 사용)
    try {
        ICONS = {
            university: {
                url: "/static/img/pin-univ.png",
                scaledSize: new google.maps.Size(64, 64),
                anchor: new google.maps.Point(32, 64)
            },
            school: {
                url: "/static/img/pin-school.png",
                scaledSize: new google.maps.Size(50, 50),
                anchor: new google.maps.Point(25, 50)
            }
        };
    } catch (e) {
        console.error("Icon Init Error:", e);
    }

    // 3. 지도 생성
    const japanCenter = { lat: 36.2048, lng: 138.2529 };
    map = new google.maps.Map(document.getElementById("map"), {
        center: japanCenter,
        zoom: 5,
        mapTypeControl: false,
        streetViewControl: false,
        fullscreenControl: true,
        styles: [{ "featureType": "poi", "elementType": "labels", "stylers": [{ "visibility": "off" }] }]
    });

    infoWindow = new google.maps.InfoWindow({ maxWidth: 320 });

    // 4. 마커 렌더링 (데이터가 있을 때만)
    if (dataCount > 0) {
        renderMarkers(SCHOOLS_DATA);
    }

    // 5. 이벤트 리스너 등록
    bindEvents();
    
    // 6. 초기 버튼 상태 설정 (Search만 보이게)
    toggleButtons(false);
}

function bindEvents() {
    // 필터 변경 시 UI 업데이트
    document.querySelectorAll('.search-container select').forEach(select => {
        select.addEventListener('change', () => {
            updateFilterUI();
            // applyFilters(); // 자동 검색 원하면 주석 해제
        });
    });

    // 검색창 입력 이벤트
    const univInput = document.getElementById("filter-univ");
    if (univInput) {
        univInput.addEventListener('keypress', (e) => {
             if (e.key === 'Enter') applyFilters();
        });
        univInput.addEventListener('input', () => {
             updateFilterUI();
        });
    }
}

function updateFilterUI() {
    // 필터 활성화 시 색상 변경
    document.querySelectorAll('.search-container select').forEach(sel => {
        if (sel.value !== 'all') sel.classList.add('active-filter');
        else sel.classList.remove('active-filter');
    });

    const input = document.getElementById("filter-univ");
    if (input) {
        if (input.value.trim() !== "") input.classList.add('active-filter');
        else input.classList.remove('active-filter');
    }
}

function toggleButtons(isFiltered) {
    const searchBtn = document.getElementById("search-btn");
    const resetBtn = document.getElementById("reset-btn");
    
    if (searchBtn && resetBtn) {
        if (isFiltered) {
            searchBtn.style.display = "none";
            resetBtn.style.display = "inline-block"; // flex 대신 inline-block이 안전할 수 있음
        } else {
            searchBtn.style.display = "inline-block";
            resetBtn.style.display = "none";
        }
    }
}

function renderMarkers(data) {
    // 마커 초기화
    if (markerCluster) markerCluster.clearMarkers();
    schoolMarkers.forEach(m => m.setMap(null));
    univMarkers.forEach(m => m.setMap(null));
    schoolMarkers = [];
    univMarkers = [];

    const bounds = new google.maps.LatLngBounds();
    const lang = (typeof currentLang !== 'undefined') ? currentLang : 'en';
    const t = (typeof translations !== 'undefined' && translations[lang]) ? translations[lang] : (translations['en'] || {});

    data.forEach(item => {
        if (!item.location || !item.location.lat) return;
        const position = { lat: item.location.lat, lng: item.location.lng };
        
        let dispName = item.basic_info.name_ja;
        if (lang === 'en' && item.basic_info.name_en) {
            dispName = item.basic_info.name_en;
        }

        // [대학 마커]
        if (item.category === 'university') {
            const marker = new google.maps.Marker({
                position: position,
                map: map,
                title: dispName,
                zIndex: 9999,
                icon: ICONS.university,
            });

            marker.addListener("click", () => {
                const content = `
                <div class="info-window-card">
                    <div class="iw-header" style="background:#0F4C81;">
                        <a href="/school/${item.id}" class="iw-title">🎓 ${dispName}</a>
                    </div>
                    <div class="iw-body">
                        <div class="iw-row"><i class="fas fa-map-marker-alt iw-icon"></i> ${item.basic_info.address}</div>
                        <a href="${item.basic_info.website}" target="_blank" class="iw-btn" style="background:#0F4C81;">${t.iw_univ_home || 'Website'}</a>
                    </div>
                </div>`;
                infoWindow.setContent(content);
                infoWindow.open(map, marker);
            });
            univMarkers.push(marker); 
            bounds.extend(position);
        } 
        // [어학원 마커]
        else {
            const fees = item.courses ? item.courses.map(c => c.total_fees || 9999999) : [];
            const minFee = Math.min(...fees);
            let feeText = '-';
            if (minFee !== 9999999) {
                if(lang === 'en') feeText = "¥" + (minFee/10000).toLocaleString() + "0k";
                else feeText = (minFee/10000).toLocaleString() + (t.unit_money || '만엔');
            }

            const marker = new google.maps.Marker({
                position: position,
                title: dispName,
                zIndex: 1,
                icon: ICONS.school
            });

            marker.addListener("click", () => {
                const featureTags = (item.features || []).slice(0, 3).map(f => `<span class="iw-tag">${f}</span>`).join('');
                const content = `
                <div class="info-window-card">
                    <div class="iw-header" style="background:#F28C28;">
                        <a href="/school/${item.id}" class="iw-title">🏫 ${dispName}</a>
                    </div>
                    <div class="iw-body">
                        <div class="iw-row"><i class="fas fa-map-marker-alt iw-icon"></i> ${item.basic_info.address}</div>
                        <div class="iw-row"><i class="fas fa-users iw-icon"></i> ${t.iw_capacity || 'Cap'}: ${item.basic_info.capacity}</div>
                        <div class="iw-row"><i class="fas fa-yen-sign iw-icon"></i> ${feeText}</div>
                        <div class="iw-tags">${featureTags}</div>
                        <a href="/school/${item.id}" class="iw-btn" style="background:#F28C28;">${t.iw_school_detail || 'Detail'}</a>
                    </div>
                </div>`;
                infoWindow.setContent(content);
                infoWindow.open(map, marker);
            });
            schoolMarkers.push(marker);
            bounds.extend(position);
        }
    });

    // 클러스터링
    try {
        markerCluster = new markerClusterer.MarkerClusterer({ markers: schoolMarkers, map });
    } catch(e) {
        console.warn("MarkerClusterer not loaded", e);
    }

    // 결과 수 업데이트
    const countEl = document.getElementById("result-count");
    if (countEl) countEl.innerText = schoolMarkers.length + univMarkers.length;

    // 지도 범위 조정 (검색 이동 아닐 때만)
    if (!window.isSearchMove && (schoolMarkers.length + univMarkers.length) > 0) {
         map.fitBounds(bounds);
    }
}

function checkNameMatch(item, query) {
    if (!query) return false;
    query = query.toLowerCase();
    
    if (item.basic_info.name_ja && item.basic_info.name_ja.toLowerCase().includes(query)) return true;
    if (item.basic_info.name_en && item.basic_info.name_en.toLowerCase().includes(query)) return true;
    
    if (item.career_path && item.career_path.major_universities) {
        let keywords = [query];
        // 간이 매핑
        if (query.includes('waseda')) keywords.push('早稲田');
        if (query.includes('keio')) keywords.push('慶應');
        if (query.includes('meiji')) keywords.push('明治');
        if (query.includes('tokyo')) keywords.push('東京');
        
        return item.career_path.major_universities.some(univ => 
            keywords.some(k => univ.toLowerCase().includes(k))
        );
    }
    return false;
}

function applyFilters() {
    const region = document.getElementById("filter-region")?.value || "all";
    const univInput = document.getElementById("filter-univ")?.value.trim().toLowerCase() || "";
    
    // ... 필터값 가져오기 (생략된 부분 없이 모두 가져와야 함) ...
    const price = document.getElementById("filter-price")?.value || "all";
    // ... (나머지 필터 변수들: nation, scale, career, special, dorm, scholarship, eju, convo, env) ...
    // 코드 길이상 생략했으나 실제 파일엔 있어야 합니다.

    let targetUnivLocation = null;
    if (univInput !== "") {
        const targetUniv = SCHOOLS_DATA.find(s => 
            s.category === 'university' && checkNameMatch(s, univInput)
        );
        if (targetUniv && targetUniv.location) {
            targetUnivLocation = targetUniv.location;
        }
    }

    const filtered = SCHOOLS_DATA.filter(s => {
        // [A] 대학
        if (s.category === 'university') {
            if (univInput !== "") return checkNameMatch(s, univInput);
            return false; 
        }

        // [B] 어학원
        const addr = s.basic_info.address || "";
        if (region !== "all" && !addr.includes(region)) return false;

        // 대학 진학 실적
        if (univInput !== "") {
            if (!checkNameMatch(s, univInput)) return false; 
        }
        
        // 가격 필터 예시
        if (price !== "all") {
             const fees = (s.courses || []).map(c => c.total_fees).filter(f => typeof f === 'number');
             if (fees.length === 0 || Math.min(...fees) > parseInt(price) * 10000) return false;
        }
        
        // ... 나머지 필터 로직들 ...
        
        return true;
    });

    window.isSearchMove = !!(targetUnivLocation && univInput !== "");
    
    renderMarkers(filtered);

    if (targetUnivLocation) {
        map.panTo(targetUnivLocation);
        map.setZoom(14);
    }

    updateFilterUI();
    toggleButtons(true); // 검색 후엔 Reset 버튼 표시
}

function resetFilters() {
    document.querySelectorAll(".search-container select").forEach(el => el.value = 'all');
    const univInput = document.getElementById("filter-univ");
    if(univInput) univInput.value = "";
    
    window.isSearchMove = false;
    renderMarkers(SCHOOLS_DATA);
    updateFilterUI();
    toggleButtons(false); // 초기화 후엔 Search 버튼 표시
    
    map.setZoom(5);
    map.setCenter({ lat: 36.2048, lng: 138.2529 });
}